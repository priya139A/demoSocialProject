package com.project.entities;

public class IdObject {
	private int id;

	public IdObject(int id) {
		super();
		this.id = id;
	}
	public IdObject() {
		
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}

